title: Dolor sit amet
subtitle: lorem ipsum
author: Michel Peron
published: 2021-09-01
template: col2
type: article


#Dolor sit amet 

This is an inline-style link to our [markdown cheat sheet](/markdown-cheat-sheet)

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Consequat ac felis donec et odio pellentesque diam. Ut sem viverra aliquet eget sit amet tellus cras. Scelerisque varius morbi enim nunc faucibus a pellentesque sit. Blandit turpis cursus in hac habitasse platea. Tincidunt nunc pulvinar sapien et. Et sollicitudin ac orci phasellus egestas. Et malesuada fames ac turpis egestas maecenas pharetra. Viverra suspendisse potenti nullam ac. Hac habitasse platea dictumst quisque sagittis purus sit. Eleifend mi in nulla posuere sollicitudin. Dictumst quisque sagittis purus sit amet volutpat consequat. Consectetur adipiscing elit ut aliquam. Cras semper auctor neque vitae tempus quam.

>  QUOTATION Enim praesent elementum facilisis leo vel fringilla est. Faucibus purus in massa tempor nec feugiat nisl. Dictum fusce ut placerat orci. Mi in nulla posuere sollicitudin aliquam ultrices sagittis orci. Nunc consequat interdum varius sit amet. Vestibulum mattis ullamcorper velit sed ullamcorper morbi tincidunt. At varius vel pharetra vel. In dictum non consectetur a erat. At risus viverra adipiscing at in. Amet purus gravida quis blandit turpis. Gravida in fermentum et sollicitudin ac orci phasellus egestas. Eget nullam non nisi est sit amet facilisis. In vitae turpis massa sed elementum tempus egestas. Feugiat sed lectus vestibulum mattis ullamcorper velit. Lacus suspendisse faucibus interdum posuere lorem ipsum dolor sit amet. Et egestas quis ipsum suspendisse. Vulputate dignissim suspendisse in est ante in nibh. Vulputate sapien nec sagittis aliquam malesuada bibendum.

| Item         | Price | # In stock |
|--------------|:-----:|-----------:|
| Juicy Apples |  1.99 |        739 |
| Bananas      |  1.89 |          6 |

**Sit amet volutpat consequat mauris nunc.** Quam elementum pulvinar etiam non. Non diam phasellus vestibulum lorem sed risus ultricies tristique nulla. Orci a scelerisque purus semper eget duis at tellus. Ornare suspendisse sed nisi lacus. Leo a diam sollicitudin tempor id. Sed viverra ipsum nunc aliquet bibendum enim facilisis. Sit amet tellus cras adipiscing enim. Adipiscing vitae proin sagittis nisl rhoncus mattis rhoncus. Nisl nunc mi ipsum faucibus vitae. Purus non enim praesent elementum facilisis. Eleifend quam adipiscing vitae proin sagittis nisl rhoncus mattis. Tincidunt eget nullam non nisi est sit amet facilisis magna. Pharetra sit amet aliquam id diam maecenas ultricies mi eget. Vel elit scelerisque mauris pellentesque pulvinar. Et pharetra pharetra massa massa ultricies mi quis hendrerit. Ut tellus elementum sagittis vitae et leo duis. Morbi leo urna molestie at elementum.

*Sit amet risus nullam eget felis eget nunc lobortis.* Urna id volutpat lacus laoreet non curabitur gravida. Pharetra convallis posuere morbi leo urna. A lacus vestibulum sed arcu non odio euismod. Vel fringilla est ullamcorper eget nulla. Venenatis lectus magna fringilla urna porttitor rhoncus dolor. Maecenas volutpat blandit aliquam etiam. Adipiscing elit ut aliquam purus sit amet. Amet consectetur adipiscing elit ut aliquam. Elementum pulvinar etiam non quam lacus suspendisse. Amet consectetur adipiscing elit ut aliquam purus. Facilisis volutpat est velit egestas. Euismod in pellentesque massa placerat duis. Hac habitasse platea dictumst vestibulum rhoncus. Dignissim diam quis enim lobortis scelerisque fermentum dui. Ultricies integer quis auctor elit sed vulputate. Turpis egestas pretium aenean pharetra magna. Quis eleifend quam adipiscing vitae proin sagittis. Tellus cras adipiscing enim eu.

***Elementum acilisis leo vel fringilla est ullamcorper.*** Vehicula ipsum a arcu cursus. Morbi tincidunt ornare massa eget egestas purus. Eget est lorem ipsum dolor sit amet. Morbi blandit cursus risus at ultrices mi tempus imperdiet nulla. Odio facilisis mauris sit amet massa. Urna porttitor rhoncus dolor purus. Sit amet cursus sit amet dictum. Dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Vitae suscipit tellus mauris a diam maecenas sed enim. Turpis in eu mi bibendum. Nunc sed velit dignissim sodales. Orci porta non pulvinar neque. Eu sem integer vitae justo. Ut lectus arcu bibendum at varius vel pharetra vel. 


<key>KEYBOARD</key> <key>CTRL</key> <key>ALT</key> <key>SUPR</key>
##Level2 Title 

Eget sit amet tellus cras. `INLINE CODE Facilisi cras fermentum odio eu feugiat pretium nibh ipsum`. Imperdiet sed euismod nisi porta lorem. Massa tincidunt nunc pulvinar sapien et ligula ullamcorper malesuada proin. Sit amet mauris commodo quis imperdiet massa tincidunt nunc. Dolor magna eget est lorem ipsum dolor sit amet consectetur. Viverra maecenas accumsan lacus vel facilisis. Quis risus sed vulputate odio ut enim blandit. Pretium vulputate sapien nec sagittis aliquam malesuada. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra.

- Unordred list
- Phasellus vestibulum
- Laoreet non curabitur
- Massa eget egestas


Eget sit amet tellus cras. Facilisi cras fermentum odio eu feugiat pretium nibh ipsum. Imperdiet sed euismod nisi porta lorem. Massa tincidunt nunc pulvinar sapien et ligula ullamcorper malesuada proin. Sit amet mauris commodo quis imperdiet massa tincidunt nunc. Dolor magna eget est lorem ipsum dolor sit amet consectetur. Viverra maecenas accumsan lacus vel facilisis. Quis risus sed vulputate odio ut enim blandit. Pretium vulputate sapien nec sagittis aliquam malesuada. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra.


1. Ordred list
2. Phasellus vestibulum
3. Laoreet non curabitur
4. Massa eget egestas



###Level3 Title
Phasellus vestibulum lorem sed risus ultricies tristique nulla aliquet enim. Arcu cursus vitae congue mauris rhoncus aenean. Aliquam eleifend mi in nulla posuere. Diam vel quam elementum pulvinar etiam non quam lacus. Eget nulla facilisi etiam dignissim diam quis enim. Molestie ac feugiat sed lectus vestibulum mattis ullamcorper velit sed. Aliquet lectus proin nibh nisl condimentum id venenatis a condimentum. In massa tempor nec feugiat nisl. Cursus eget nunc scelerisque viverra mauris in aliquam sem fringilla. Tortor vitae purus faucibus ornare suspendisse sed. Leo urna molestie at elementum eu facilisis.

- [x] Apples
- [ ] Bananas
- [ ] Peanut butter



####Level4 Title


    BLOCK OF CODE 
    @font-face {
        font-family: 'belgika5th';
        src: url('fonts/belgika-5th-webfont.woff2') format('woff2'),
             url('fonts/belgika-5th-webfont.woff') format('woff');
        font-weight: normal;
        font-style: normal;
    }
    
    @font-face {
        font-family: 'josafronderegular';
        src: url('fonts/josafronde-regular-webfont.woff2') format('woff2'),
             url('fonts/josafronde-regular-webfont.woff') format('woff');
        font-weight: normal;
        font-style: normal;
    }




Laoreet non curabitur gravida arcu. Lacus sed turpis tincidunt id aliquet risus feugiat in. Odio euismod lacinia at quis. Semper eget duis at tellus at urna condimentum. Et odio pellentesque diam volutpat commodo sed egestas. Arcu non sodales neque sodales ut etiam sit. Sed augue lacus viverra vitae congue eu consequat ac felis. Lectus nulla at volutpat diam ut venenatis. Nulla facilisi cras fermentum odio. Egestas maecenas pharetra convallis posuere morbi leo. Et ultrices neque ornare aenean. Metus dictum at tempor commodo ullamcorper a lacus. Etiam non quam lacus suspendisse faucibus interdum posuere lorem. Lectus magna fringilla urna porttitor. Congue quisque egestas diam in arcu.

Massa eget egestas purus viverra accumsan. Vestibulum mattis ullamcorper velit sed ullamcorper morbi tincidunt. Ultricies lacus sed turpis tincidunt id. Egestas dui id ornare arcu odio. Neque volutpat ac tincidunt vitae semper quis lectus. In dictum non consectetur a erat nam at lectus urna. Sociis natoque penatibus et magnis dis parturient montes. Et tortor at risus viverra adipiscing. Maecenas pharetra convallis posuere morbi leo urna molestie at elementum. Dolor sit amet consectetur adipiscing. Et sollicitudin ac orci phasellus.

*![alt](https://pixy.org/src/465/4654979.jpg)*

Massa enim nec dui nunc mattis enim. Id aliquet lectus proin nibh nisl condimentum id. Risus nec feugiat in fermentum posuere. Et tortor consequat id porta nibh. Facilisis leo vel fringilla est ullamcorper eget nulla facilisi etiam. Fusce id velit ut tortor pretium viverra. Sollicitudin aliquam ultrices sagittis orci a. Adipiscing vitae proin sagittis nisl rhoncus mattis rhoncus. Aliquam ut porttitor leo a diam. Scelerisque varius morbi enim nunc faucibus a pellentesque. Malesuada fames ac turpis egestas maecenas pharetra convallis.

Ac turpis egestas integer eget aliquet nibh. Laoreet suspendisse interdum consectetur libero id faucibus. Vel quam elementum pulvinar etiam. Auctor elit sed vulputate mi. Enim blandit volutpat maecenas volutpat blandit. Sit amet commodo nulla facilisi nullam vehicula ipsum a arcu. Accumsan lacus vel facilisis volutpat est velit. Et molestie ac feugiat sed lectus vestibulum mattis. Ut morbi tincidunt augue interdum velit euismod in pellentesque. Enim ut tellus elementum sagittis vitae et leo duis ut. Augue neque gravida in fermentum et sollicitudin ac.

Enim tortor at auctor urna nunc. A scelerisque purus semper eget duis at tellus at urna. Ac felis donec et odio pellentesque diam volutpat commodo. At imperdiet dui accumsan sit amet nulla. Tellus mauris a diam maecenas. Donec ac odio tempor orci dapibus ultrices in iaculis. Vitae congue mauris rhoncus aenean vel. Arcu non odio euismod lacinia at. Velit sed ullamcorper morbi tincidunt ornare. Euismod lacinia at quis risus sed vulputate odio ut enim. Montes nascetur ridiculus mus mauris vitae ultricies leo integer malesuada. Rutrum quisque non tellus orci ac auctor. Mattis pellentesque id nibh tortor id aliquet lectus. Morbi tristique senectus et netus et malesuada fames ac. Quam id leo in vitae turpis massa. Suspendisse potenti nullam ac tortor vitae purus faucibus. Morbi enim nunc faucibus a. Quam lacus suspendisse faucibus interdum posuere.

![alt](https://pixy.org/src/465/4654979.jpg)

Pulvinar elementum integer enim neque volutpat. Quis imperdiet massa tincidunt nunc pulvinar sapien et ligula. Orci nulla pellentesque dignissim enim sit amet venenatis. Quisque egestas diam in arcu. Bibendum enim facilisis gravida neque convallis a cras semper. Habitant morbi tristique senectus et netus et malesuada fames. Ut aliquam purus sit amet luctus. Ipsum dolor sit amet consectetur adipiscing elit pellentesque. Turpis egestas sed tempus urna et pharetra. Nunc sed velit dignissim sodales ut eu sem integer. Augue lacus viverra vitae congue eu consequat ac felis. Adipiscing elit ut aliquam purus sit. Orci porta non pulvinar neque laoreet. Mauris pellentesque pulvinar pellentesque habitant. Molestie at elementum eu facilisis sed odio morbi quis commodo. Sit amet massa vitae tortor condimentum. Erat imperdiet sed euismod nisi porta lorem. Fringilla urna porttitor rhoncus dolor purus non enim. Id porta nibh venenatis cras. Amet aliquam id diam maecenas ultricies mi eget mauris pharetra.

Semper feugiat nibh sed pulvinar proin gravida hendrerit. Lorem mollis aliquam ut porttitor leo a. Arcu bibendum at varius vel pharetra vel. Arcu dictum varius duis at. Ornare massa eget egestas purus viverra accumsan in nisl. Sem fringilla ut morbi tincidunt. Fermentum leo vel orci porta non pulvinar neque laoreet suspendisse. Ut venenatis tellus in metus vulputate eu scelerisque felis. Cum sociis natoque penatibus et magnis dis parturient montes. Amet facilisis magna etiam tempor. Potenti nullam ac tortor vitae purus. Vehicula ipsum a arcu cursus vitae congue mauris rhoncus aenean. Phasellus faucibus scelerisque eleifend donec. Amet est placerat in egestas erat imperdiet. Nullam vehicula ipsum a arcu. Tellus in metus vulputate eu scelerisque felis imperdiet proin fermentum. Ipsum consequat nisl vel pretium lectus quam id leo in. In tellus integer feugiat scelerisque. Ultrices eros in cursus turpis.

Purus viverra accumsan in nisl nisi scelerisque eu. At augue eget arcu dictum varius. Nascetur ridiculus mus mauris vitae ultricies leo integer malesuada nunc. Vitae congue eu consequat ac felis donec et. Id diam maecenas ultricies mi eget mauris pharetra. Nunc sed velit dignissim sodales ut eu. Vitae elementum curabitur vitae nunc sed velit dignissim sodales ut. Auctor augue mauris augue neque gravida. Id porta nibh venenatis cras. Consequat ac felis donec et odio pellentesque diam. Eros in cursus turpis massa. Lacinia quis vel eros donec ac odio tempor. Vulputate ut pharetra sit amet aliquam. Commodo nulla facilisi nullam vehicula ipsum a arcu cursus vitae.

